/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : Program for the 8051 to read state of SW_01 and display SW_01 state in LED_01                      									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :  NOT WORKING    							
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"

static unsigned int volatile *const io_port_base_ptr[] = {(unsigned int *) 0x80,(unsigned int *) 0x90, (unsigned int *) 0xA0,  (unsigned int *) 0xB0};
disp_format_t disp_format_data;
static unsigned int IO_Ch_Validate(const unsigned int io_ch_id);
/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :          
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
void main(void)
{
	 unsigned int read_sw_01;	
	 bit led_01_state = STATE_OFF; 
	 
	 /* ========= begin : USER CODE INITIALIZE ========== */
	 ERROR_LED = 0;         //output for MCU	 
	 UART_Init(); 
	 Pin_Func_Init(LED_01_CH_ID, FUNC_OUTPUT);
	// Pin_Func_Init(SW_01_CH_ID, FUNC_INPUT);
	 UART_Tx_Str("Info: Init over\r");
   	 /* ========= end : USER CODE INITIALIZE ========== */
	   
     while(1) // Super Loop
     {
		   /* IO_CH_Read(SW_01_CH_ID, &read_sw_01);
		   IO_CH_Write(LED_01_CH_ID, read_sw_01);
           if(read_sw_01 == STATE_ON) 
		   {
		     	 if(led_01_state == STATE_OFF)
				 {
				     led_01_state = STATE_ON;
			         UART_Tx_Str("INFO: LED_01 - ON, SW_01 - CLOSED \r");
				 }						 
			}
			else
			{
			    if(led_01_state == STATE_ON)
				{
				    led_01_state = STATE_OFF;
				   	UART_Tx_Str("INFO: LED_01 - OFF, SW_01 - OPENED \r");
				}
			} */
		    IO_CH_Write(LED_01_CH_ID, STATE_ON);
			UART_Tx_Str("INFO: LED_01 - ON \r");
			Delay_in_Milli_Sec(300UL);
		   	IO_CH_Write(LED_01_CH_ID, STATE_OFF);
			UART_Tx_Str("INFO: LED_01 - OFF \r");
		    Delay_in_Milli_Sec(300UL);
     }	   
	 return; 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Pin_Func_Init

DESCRIPTION    :          
								
INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
void Pin_Func_Init(const unsigned int io_ch_id, const func_t pin_func)
{
	volatile int pdata *io_port_ptr;
	unsigned char port_id, port_pin_id;
	
	IO_Ch_Validate(io_ch_id);
	port_id = io_ch_id / CHS_PER_PORT;
	port_pin_id = io_ch_id % CHS_PER_PORT;
	io_port_ptr = io_port_base_ptr[port_id] + (port_pin_id / 2); 
	switch(pin_func)
	{
		case FUNC_OUTPUT:
		  *io_port_ptr = 0;
		break;
		case FUNC_INPUT:
		  *io_port_ptr = 1;
		break;
		default:
		  return; 
	}
	return; 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : IO_CH_Write

DESCRIPTION    :          
								
INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int IO_CH_Write(const unsigned int io_ch_id, const bit output_data)
{
	volatile int pdata *io_port_ptr; 
	unsigned char port_id, port_pin_id;
	
	IO_Ch_Validate(io_ch_id);
	port_id = io_ch_id / CHS_PER_PORT;
	port_pin_id = io_ch_id % CHS_PER_PORT;
	
	io_port_ptr = io_port_base_ptr[port_id] + (port_pin_id / 2); 
	*io_port_ptr = output_data;
   
	UART_Tx_Str("TRA: IO CH - ");
	disp_format_data.disp_sign = STATE_NO;
    disp_format_data.num_digits_format = DISP_NUM_DIGIT2;
    disp_format_data.disp_data = io_ch_id;	 
	UART_Disp_Num(disp_format_data);
	UART_Tx_Str("  , Pin Ptr : 0x");
	disp_format_data.disp_sign = STATE_NO;
    disp_format_data.num_digits_format = DISP_HEX_DIGIT2;
	disp_format_data.disp_data = (unsigned long) io_port_ptr;
	UART_Disp_Num(disp_format_data);
	if(*io_port_ptr)
		UART_Tx_Str(" , State - ON \r");
	else
		UART_Tx_Str(" , State - OFF \r");	

	
	return SUCCESS; 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : IO_CH_Read

DESCRIPTION    :          
								
INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int IO_CH_Read(const unsigned int io_ch_id, unsigned char *read_ch_ptr)
{
	unsigned int volatile *io_port_ptr; 
	unsigned int port_id, port_pin_id;
	
	if(read_ch_ptr == NULL_PTR)
	{
		UART_Tx_Str("ERR: IO_CH_Read \r");
		return ERR_NULL_PTR;
	}
	IO_Ch_Validate(io_ch_id);
	
	port_id = io_ch_id / CHS_PER_PORT;
	port_pin_id = io_ch_id % CHS_PER_PORT;
	
	io_port_ptr = io_port_base_ptr[port_id] + port_pin_id; 	
	*read_ch_ptr = *io_port_ptr; 		
	return SUCCESS; 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : IO_Ch_Validate

DESCRIPTION    :          
								
INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int IO_Ch_Validate(const unsigned int io_ch_id)
{
	if(io_ch_id >= NUM_CHS)
	{
		UART_Tx_Str("ERR: IO_Ch_Validate \r");
		return ERR_DATA_NOT_IN_RANGE;
	}
	return SUCCESS; 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Interrupt_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        :   
-*------------------------------------------------------------*/
void Global_Interrupt_Enable()
{
	EA = 1;
    return; 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Delay_in_Micro_Sec

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        :   
-*------------------------------------------------------------*/
void Delay_in_Micro_Sec(const unsigned long num_micro_seconds)
{
	unsigned int i = 0;
	
	for (i = 0;  i < num_micro_seconds; ++i);
	return; 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Delay_in_Milli_Sec

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        :   
-*------------------------------------------------------------*/
void Delay_in_Milli_Sec(const unsigned long num_milli_seconds)
{
	unsigned int i = 0;
	
	for (i = 0;  i < num_milli_seconds; ++i)
	  Delay_in_Micro_Sec(NUM_COUNT_MICRO_SEC);
	return;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_Fill_Char

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        :    
-*------------------------------------------------------------*/
unsigned int Str_Fill_Char(char *const dest_str, const unsigned char num_chars, const char fill_char)
{
	unsigned char index;
	
	if(dest_str == NULL_PTR || num_chars > STR_MAX_NUM_CHARS)
	{
		UART_Tx_Str("ERR: Str_Fill\r");
		return ERR_INVALID_DATA;
	}
	for (index = 0 ; index < num_chars ; ++index)
	   *(dest_str + index)  = fill_char;
    *(dest_str + index) = NULL_CHAR;
	
	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/	 
