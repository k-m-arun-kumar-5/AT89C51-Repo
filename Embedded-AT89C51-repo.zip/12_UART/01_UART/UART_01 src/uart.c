/* ********************************************************************
FILE                 : uart.c

PURPOSE              : 
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : 								

CHANGE LOGS          :

*****************************************************************************/

#include "main.h"

// ------  data type declarations ---------------------------

// ------  function prototypes ------------------------------
static unsigned int UART_Rx_Char_Proc(const unsigned char uart_id);
static void UART_Timer_Rcvd_First_Bit_Proc();
static void UART_Timer_One_Bit_Proc();
 
// ------  constants ----------------------------------------


// ------  variables ----------------------------------------
uart_data_t uart_data[NUM_UARTS];

/*------------------------------------------------------------*-
FUNCTION NAME  : UART_Init

DESCRIPTION    : Initialize UART port						 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int UART_Init(const unsigned char uart_id)
{
	switch(uart_id)
	{
		case INTR_UART_CH_ID:
		   #ifdef UART_EVENT == INTERRUPT
		       Global_Interrupt_Enable();
			   ES = 1; 
		   #endif
		   SCON = 0x50;    // setup serial port control 
  	       TMOD = 0x20;    // hardware (9600 BAUD @11.0592MHZ) 
  	       TH1  = 0xFD;    // TH1  
  	       TR1	 = 1;  		// Timer 1 on
		break;
        case CUSTOM_UART_CH_ID:
           UART_TX_8051 = 0; // outout of 8051
	       UART_RX_8051 = 1; // input of 8051
	       UART_TX_8051 = 1; // idle state 	
	       Timer_Init(CH_ID_00);
		break;
        default:
		  return ERR_DATA_NOT_IN_RANGE;
	}
	UART_Reset_Datas(uart_id, UART_RESET_ALL_DATAS);	
	Delay_in_Milli_Sec(1);	
	
	return SUCCESS;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : UART_Reset_Datas

DESCRIPTION    :					 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int UART_Reset_Datas(const unsigned char uart_id, const unsigned char uart_reset_type)
{
	if(uart_id >= NUM_UARTS)
	{
		return ERR_DATA_NOT_IN_RANGE;
	}
	switch(uart_reset_type)
	{
		case UART_RESET_ALL_DATAS:
		case UART_RESET_ALL_RCVD_DATAS:
		    uart_data[uart_id].rcvd_ready_flag = STATE_YES;		 		 
		    uart_data[uart_id].echo_rcvd_data_flag = STATE_YES;
		case UART_RESET_READ_DATA:
    		uart_data[uart_id].read_flag = STATE_YES;  
		case UART_RESET_RCVD_BUFFER:		
	        Str_Fill_Char(uart_data[uart_id].rcvd_str, STR_MAX_NUM_CHARS ,NULL_CHAR); 
	        uart_data[uart_id].rcvd_str_num_chars = 0;
		    uart_data[uart_id].rcvd_overflow_flag = STATE_NO;
		    uart_data[uart_id].rcvd_char = NULL_CHAR;
		    uart_data[uart_id].rcvd_terminator_char_flag = STATE_NO;		   
		if(uart_reset_type != UART_RESET_ALL_DATAS)
			  break;
		case UART_RESET_ALL_TX_DATAS:
          	uart_data[uart_id].tx_ready_flag = STATE_YES;
		break;
        default:
           return ERR_DATA_NOT_IN_RANGE; 		
	}
	return SUCCESS;
}
/*------------------------------------------------------------*-
FUNCTION NAME  : UART_Tx_Char

DESCRIPTION    :  				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int UART_Tx_Char(const unsigned char uart_id, const char tx_char)
{
	char index = 0 ;
	
	if(uart_id >= NUM_UARTS)
	{
		return ERR_DATA_NOT_IN_RANGE;
	}
	if(uart_data[uart_id].tx_ready_flag == STATE_YES)
	{
		uart_data[uart_id].tx_ready_flag = STATE_NO; 
		switch(uart_id)
		{
			case INTR_UART_CH_ID:
			  SBUF = tx_char;
		      uart_data[uart_id].tx_ready_flag = STATE_NO; 
              if(UART_EVENT == POLLING)
		      {			
	              while (TI==0); //Transmit Char by polling 
	              TI = 0;
		          uart_data[uart_id].tx_ready_flag = STATE_YES; 
		      }
            break;
            case CUSTOM_UART_CH_ID:
			   UART_TX_8051 = 0;	//start bit
		       UART_Timer_One_Bit_Proc(); 
               for(index = 0; index < 8; ++index)
		       {	
	               UART_TX_8051 = Test_Bit_Is_Set_in_Data(&tx_char, index); 
	               UART_Timer_One_Bit_Proc();  		    
		       }
		       UART_TX_8051 = 1;	//stop bit
		       UART_Timer_One_Bit_Proc(); 
            break;            		
		}
		uart_data[uart_id].tx_ready_flag = STATE_YES; 
		return SUCCESS; 
	}		
	return ERR_UART_TX_NOT_READY; 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : UART_Tx_Str

DESCRIPTION    : Transmit String by polling 				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int UART_Tx_Str(const unsigned char uart_id, const char *const tx_str)
{
     unsigned char index;
	 
	 if(uart_id >= NUM_UARTS || tx_str == NULL_PTR)
	 {
		 return ERR_DATA_NOT_IN_RANGE;
	 }
     for(index = 0; ((*(tx_str + index)) != NULL_CHAR); index++)
	 {
		  if(((UART_Tx_Char(uart_id, (*(tx_str + index)))) != SUCCESS))
		      return ERR_UART_TX_NOT_READY;		 
	 }
	 return SUCCESS; 
}

#ifdef UART_EVENT == INTERRUPT
/*------------------------------------------------------------*-
FUNCTION NAME  : Serial_ISR 

DESCRIPTION    : UART by Interrupt 				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
void Serial_ISR(void) interrupt 4
{
	unsigned char uart_id = INTR_UART_CH_ID;
	
	if(RI == 1)
	{
		uart_data[uart_id].rcvd_ready_flag = STATE_NO; 
		uart_data[uart_id].rcvd_char = SBUF; 
		UART_Rx_Char_Proc(uart_id);		
		RI = 0; //clear uart receive flag		
	}
	if(TI == 1)
	{
	    TI = 0;           //clear uart transmit flag
	    uart_data[uart_id].tx_ready_flag = STATE_YES; 
	}	
}	

#else
/*------------------------------------------------------------*-
FUNCTION NAME  : UART_Rx_Char

DESCRIPTION    : Receive Char by polling 				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
char UART_Rx_Char(const unsigned char uart_id)
{
	if(uart_id >= NUM_UARTS)
	{
		return ERR_DATA_NOT_IN_RANGE;
	}
	if(uart_data[uart_id].rcvd_str_num_chars + 1 >= STR_MAX_NUM_CHARS )
	{
		uart_data[uart_id].rcvd_overflow_flag = STATE_YES;
		return NULL_CHAR;
	}
	uart_data[uart_id].rcvd_overflow_flag = STATE_NO;
	if(uart_data[uart_id].rcvd_ready_flag == STATE_YES ) 
	{
		  uart_data[uart_id].rcvd_ready_flag = STATE_NO; 
		  switch(uart_id)
		  {
			  case INTR_UART_CH_ID:
	              while (RI==0);
	              uart_data[uart_id].rcvd_char = SBUF;
		          UART_Rx_Char_Proc(uart_id);
		          RI = 0;
              break;
              case CUSTOM_UART_CH_ID:
			     while(UART_RX_8051 == 1);  //idle state
		         UART_Timer_Rcvd_First_Bit_Proc(); 
		         for(index = 0; index < 8; ++index)
		         {	
	                uart_rcvd_char |= ((UART_RX_8051 && 1) << (index)); // sample point 
	                UART_Timer_One_Bit_Proc();  		    
		         }
		         if(UART_RX_8051 == 0)
		         {
			        return ERR_UART_STOP_BIT_MISMATCH; 			 			  
		         }
		         UART_Timer_One_Bit_Proc();
				 uart_data[uart_id].rcvd_char = uart_rcvd_char;
				 UART_Rx_Char_Proc(uart_id);
              break;
		  }			  
		  return(uart_data[uart_id].rcvd_char);		
	}
	return NULL_CHAR;  	
}
#endif

/*------------------------------------------------------------*-
FUNCTION NAME  :  

DESCRIPTION    : 				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int UART_Read(const unsigned char uart_id, const char **const read_str_ptr, const unsigned char *read_num_chars_ptr)
{
	if(uart_id >= NUM_UARTS || read_str_ptr == NULL_PTR || *read_str_ptr == NULL_PTR || read_num_chars_ptr == NULL_PTR)
	{
		UART_Tx_Str(INTR_UART_CH_ID, "ERR: UART read \r");
		return ERR_NULL_PTR;
	}
	*read_str_ptr = uart_data[uart_id].rcvd_str;
	read_num_chars_ptr = &uart_data[uart_id].rcvd_str_num_chars; 
		
	return SUCCESS;
}
/*------------------------------------------------------------*-
FUNCTION NAME  :  UART_Rx_Char_Proc

DESCRIPTION    : 				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
static unsigned int UART_Rx_Char_Proc(const unsigned char uart_id)
{
	if(uart_id >= NUM_UARTS)
	{
		return ERR_DATA_NOT_IN_RANGE;
	}
	uart_data[uart_id].read_flag = STATE_NO;
	if(uart_data[uart_id].rcvd_str_num_chars + 1 < STR_MAX_NUM_CHARS)
	{
		 uart_data[uart_id].rcvd_overflow_flag = STATE_NO;
         switch(uart_data[uart_id].rcvd_char)
		 {
              case BACKSPACE_CHAR:
		         if(uart_data[uart_id].rcvd_str_num_chars > 0)
			     {
			        if(uart_data[uart_id].echo_rcvd_data_flag == STATE_YES)
			             if(((UART_Tx_Char(uart_id, uart_data[uart_id].rcvd_char)) != SUCCESS))
							 return ERR_UART_TX_NOT_READY;
			         uart_data[uart_id].rcvd_str[uart_data[uart_id].rcvd_str_num_chars--] = NULL_CHAR;
			     }
			  break;
              case TERMINATOR_CHAR:
			     if(uart_data[uart_id].echo_rcvd_data_flag == STATE_YES)
				      if(((UART_Tx_Char(uart_id, uart_data[uart_id].rcvd_char)) != SUCCESS))
							return ERR_UART_TX_NOT_READY; 
                 uart_data[uart_id].rcvd_terminator_char_flag = STATE_YES;
              break;
              default:
			    if(uart_data[uart_id].echo_rcvd_data_flag == STATE_YES)
			         if(((UART_Tx_Char(uart_id, uart_data[uart_id].rcvd_char)) != SUCCESS))
						  return ERR_UART_TX_NOT_READY; 
			    uart_data[uart_id].rcvd_terminator_char_flag = STATE_NO; 
		        uart_data[uart_id].rcvd_str[uart_data[uart_id].rcvd_str_num_chars++] = uart_data[uart_id].rcvd_char;
		 }
		 uart_data[uart_id].rcvd_ready_flag = STATE_YES;
	}
	else
	{
        uart_data[uart_id].rcvd_overflow_flag = STATE_YES;
		return ERR_UART_RX_OVERFLOW;
	}
	return SUCCESS;  		 
}

/*------------------------------------------------------------*
FUNCTION NAME  : UART_Tx_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        :   
-*------------------------------------------------------------*/
 unsigned int UART_Tx_Num(const unsigned char uart_id, const disp_format_t uart_disp_data)
{
    unsigned int tens_thousand_digit,thousands_digit, hundreds_digit,tens_digit, unit_digit;
	unsigned long disp_num, num ;
	char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
		
	if(uart_id >= NUM_UARTS)
	{
		return ERR_DATA_NOT_IN_RANGE;
	}
	if(uart_disp_data.disp_sign  == STATE_YES) //signed lcd_datanum_disp_format
	{
		if(uart_disp_data.disp_data < 0 )
		{
			UART_Tx_Char(uart_id, '-');
			disp_num = -uart_disp_data.disp_data;
		}
        else
		{
			UART_Tx_Char(uart_id, '+');
			disp_num = uart_disp_data.disp_data;
		}        
	}
	else
	{
    	disp_num = uart_disp_data.disp_data; 
	}
	num =  disp_num ;
	
    switch(uart_disp_data.num_digits_format)
	{
	  case DISP_NUM_DIGIT5:
	 	  num =  disp_num ;
		  tens_thousand_digit = (unsigned int)(num / (unsigned long)(10000UL));
          UART_Tx_Char(uart_id, num_data[tens_thousand_digit]);
	  case DISP_NUM_DIGIT4:
	      num = disp_num % 10000UL;
	      thousands_digit = (unsigned int)(num / (unsigned long)(1000UL));
	      UART_Tx_Char(uart_id, num_data[thousands_digit]); 
	  case DISP_NUM_DIGIT3:
	      num = disp_num % 1000UL;
	      hundreds_digit = (unsigned int) (num / (unsigned long) (100));
	      UART_Tx_Char(uart_id, num_data[hundreds_digit]);
	  case DISP_NUM_DIGIT2:
	      num = disp_num % 100;
          tens_digit = (unsigned int) (num / 10);
          UART_Tx_Char (uart_id, num_data[tens_digit]); 		  
	  case DISP_NUM_DIGIT1:
	      unit_digit = (unsigned int) (disp_num % 10);
          UART_Tx_Char(uart_id, num_data[unit_digit]); 
	  break;
	  case DISP_HEX_DIGIT4:
	      //  ( 16 * 16 * 16 *16 )  = 0 as divide by zero warning 
	      //num = disp_num % ( 16 * 16 * 16 *16 );
          thousands_digit = (num / (unsigned long) (16 * 16 * 16));
	      UART_Tx_Char(uart_id, hex_data[thousands_digit]);
	  case DISP_HEX_DIGIT3:
	      num = disp_num %(unsigned long)(16 * 16 * 16);
	      hundreds_digit = (unsigned int) (num / (unsigned long) (16 * 16));
	      UART_Tx_Char(uart_id, hex_data[hundreds_digit]);
	  case DISP_HEX_DIGIT2:
	      num = disp_num %(unsigned long)(16 * 16);
          tens_digit = (unsigned int) (num / 16);
          UART_Tx_Char(uart_id, hex_data[tens_digit]);
	  case DISP_HEX_DIGIT1: 
	      unit_digit = (unsigned int) (disp_num % 16);
          UART_Tx_Char(uart_id, hex_data[unit_digit]);    
	  break;
	  default:
	     return ERR_DATA_NOT_IN_RANGE;	  
	} 
    return SUCCESS;   	
}

/*------------------------------------------------------------*
FUNCTION NAME  : UART_Timer_One_Bit_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        :   
-*------------------------------------------------------------*/
void UART_Timer_One_Bit_Proc() 
{	
    Timer_Run(CH_ID_00, TIMER_0_PULSE_LOAD_VAL);   
	while (TF0 == 0);   // Wait till timer overflows
	Timer_Stop(CH_ID_00);
	TF0 = 0;
	return ;
}		

/*------------------------------------------------------------*
FUNCTION NAME  : UART_Timer_Rcvd_First_Bit_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        :   
-*------------------------------------------------------------*/
void UART_Timer_Rcvd_First_Bit_Proc() 
{	
    Timer_Run(CH_ID_00, TIMER_0_FIRST_BIT_LOAD_VAL );   
	while (TF0 == 0);   // Wait till timer overflows
	Timer_Stop(CH_ID_00);
	TF0 = 0;
	return ;
}
	 
/*-------------------------------------------------------------------
  ------------------------ END OF FILE ------------------------------
-------------------------------------------------------------------*/

