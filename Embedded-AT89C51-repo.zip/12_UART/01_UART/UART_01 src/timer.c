/* ********************************************************************
FILE                 : timer.c

PURPOSE              : 
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : 								

CHANGE LOGS          :

*****************************************************************************/

#include "main.h"

// ------  data type declarations ---------------------------

// ------  function prototypes ------------------------------


// ------  constants ----------------------------------------


// ------  variables ----------------------------------------



/*------------------------------------------------------------*-
FUNCTION NAME  : Timer_Init

DESCRIPTION    : Initialize Timer						 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int Timer_Init(const unsigned char timer_id)
{
	switch(timer_id)
	{
		case CH_ID_00:
		   TMOD = TMOD & 0xF0 | 0x01; 		  
		break;
		case CH_ID_01:
		   TMOD = TMOD & 0x0F | 0x10; 		  
		break;
		default:
		   return ERR_DATA_NOT_IN_RANGE; 
	} 
	return SUCCESS;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Timer_Run

DESCRIPTION    :					 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int Timer_Run(const unsigned char timer_id, const unsigned long int load_val)
{
	switch(timer_id)
	{
		case CH_ID_00:
		   Timer_Load(timer_id, load_val); 
		   TR0 = 1; 		   
		break;
		case CH_ID_01:
		   Timer_Load(timer_id, load_val); 
		   TR1 = 1; 
		break;
		default:
		   return ERR_DATA_NOT_IN_RANGE; 
	} 
	return SUCCESS;
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Timer_Stop

DESCRIPTION    : 				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int Timer_Stop(const unsigned char timer_id)
{
	switch(timer_id)
	{
		case CH_ID_00:
		   TR0 = 0; 
		break;
		case CH_ID_01:
		   TR1 = 0; 
		break;
		default:
		   return ERR_DATA_NOT_IN_RANGE; 
	} 
	return SUCCESS; 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Timer_Load

DESCRIPTION    : 				 

INPUT          : 

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
unsigned int Timer_Load(const unsigned char timer_id, const unsigned long int load_val)
{
	switch(timer_id)
	{
		case CH_ID_00:
		  TH0 = (unsigned int) (load_val / 256UL);
		  TL0 = (unsigned int) (load_val % 256UL);
		break;
		case CH_ID_01:
		  TH1 = (unsigned int) (load_val / 256UL);
		  TL1 = (unsigned int) (load_val % 256UL);
		break;
		default:
		   return ERR_DATA_NOT_IN_RANGE; 
	} 
    return SUCCESS; 
}


		 
/*-------------------------------------------------------------------
  ------------------------ END OF FILE ------------------------------
-------------------------------------------------------------------*/

