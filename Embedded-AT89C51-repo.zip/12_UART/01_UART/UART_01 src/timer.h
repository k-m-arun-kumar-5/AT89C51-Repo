/**************************************************************************
   FILE          :    timer.h
 
   PURPOSE       :    Timer Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :  
 
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _TIMER_H
#define _TIMER_H
  
  
/* -------------------- public prototype declaration --------------------------------------- */
unsigned int Timer_Init(const unsigned char timer_id);
unsigned int Timer_Run(const unsigned char timer_id, const unsigned long int load_val);
unsigned int Timer_Stop(const unsigned char timer_id);
unsigned int Timer_Load(const unsigned char timer_id, const unsigned long int load_val);

#endif

/*-------------------------------------------------------------------
  ------------------------ END OF FILE ------------------------------
-------------------------------------------------------------------*/
