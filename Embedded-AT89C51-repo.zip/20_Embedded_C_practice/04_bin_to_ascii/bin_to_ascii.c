/* a program to read data in binary from P1 and then convert binary to ascii, 
   eg for 245 decimal -> 32H, 34H, 35H in little endian convention. */ 

#include <stdio.h>

#define BIN_DATA          (0xFD)
#define NUM_ASCII_DATA    (3)

void Bin_to_ASCII(unsigned char *const result_ascii_ptr, const unsigned char num_ascii_data, const unsigned char binary_data);
int main()
{
	unsigned char result_ascii[NUM_ASCII_DATA], i;
	
	Bin_to_ASCII(result_ascii, NUM_ASCII_DATA, BIN_DATA);
	for(i = 0; i < NUM_ASCII_DATA; ++i)
		printf("\n ascii[%u] = %c", i, result_ascii[i]);
    getch();		
	return 0;
}

void Bin_to_ASCII(unsigned char *const result_ascii_ptr, const unsigned char num_ascii_data, const unsigned char binary_data)
{
	unsigned char decimal_byte, temp = binary_data;
	char i;
	
	for(i = 0; i < num_ascii_data ; ++i)
	{
		*(result_ascii_ptr + i) = (temp % 10) | 0x30;		
		temp /= 10;		
	}
	return;
}
