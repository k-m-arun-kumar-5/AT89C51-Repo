/* toggle led at P1.1 with delay */

#include <reg52.h>

#define DELAY_MILLI_SEC (1000U)

sbit LED0_PIN  = P0^0;
sbit SW3_PIN = P0^1;
sbit LED3_PIN = P0^2;
sfr LED1_PORT  = 0x90; // P1 port
volatile bit sw_data  = 0x00;  
#define LED2_PORT  P2 

void Delay_MilliSec(unsigned int num_milli_sec);

void main()
{
	 LED0_PIN = 0;
	 LED0_PIN = 0;
	 LED1_PORT = 0X00;
	 LED1_PORT = 0xF8;
	 LED2_PORT = 0x00;
	 LED2_PORT = 0x0f;
 	 LED3_PIN = 0;
	 LED3_PIN = SW3_PIN; 
	 while(1)
   {
		   Delay_MilliSec(DELAY_MILLI_SEC);
		   LED0_PIN = !LED0_PIN;
		   LED1_PORT++;
		   LED2_PORT = ~LED2_PORT;
		   sw_data = SW3_PIN;	
	     LED3_PIN = sw_data;
	 }		 
}

void Delay_MilliSec(unsigned int num_milli_sec)
{
	  unsigned int i;
	  unsigned char j;
	
	  for (i = 0; i < num_milli_sec; i++)
	  	for (j = 0; j < 112; j++);	
}