/* custom UART based sync comm, serial clock with data transfer at low to high transition, with 8 bit data, no parity, LSB bit transfer first */

#include <reg52.h>

sbit ERROR_LED_PIN        = P1^4;
sbit SERIAL_RCV_CLK_PIN   = P1^5;
sbit SW_LED_PIN           = P1^6; 
sbit SERIAL_RCV_DATA_PIN  = P1^7;
		           
#define SW_LED_ON_DATA    'Y'
#define SW_LED_OFF_DATA   'N' 
#define NUM_DATA_BITS     8

void Serial_Receive_Byte(volatile unsigned char *const rcvd_byte_ptr);
void main()
{
	  volatile unsigned char rcvd_byte;
	  
	  ERROR_LED_PIN = 0;
	  ERROR_LED_PIN = 0;
	  SW_LED_PIN = 0;
	  SW_LED_PIN = 0;	  
	  while(1)
	  {
			
			Serial_Receive_Byte(&rcvd_byte);
            switch(rcvd_byte)
			{
				case SW_LED_ON_DATA:
				   ERROR_LED_PIN = 0; 
				   SW_LED_PIN = 1;
				break;
				case SW_LED_OFF_DATA:
				    ERROR_LED_PIN = 0;
				    SW_LED_PIN = 0;
				break;
				default:
				  ERROR_LED_PIN = 1;								    
			}						
	  }
}

void Serial_Receive_Byte(volatile unsigned char *const rcvd_byte_ptr)
{
	unsigned char i = 0;
	volatile unsigned char rcvd_bit;
	
	*rcvd_byte_ptr = 0;
  for (i = 0; i < NUM_DATA_BITS; ++i)
	{
	    while(SERIAL_RCV_CLK_PIN == 0);
		rcvd_bit = SERIAL_RCV_DATA_PIN;
		*rcvd_byte_ptr |= (rcvd_bit << i);		  
	    while(SERIAL_RCV_CLK_PIN == 1);
	}
	return;	
}

