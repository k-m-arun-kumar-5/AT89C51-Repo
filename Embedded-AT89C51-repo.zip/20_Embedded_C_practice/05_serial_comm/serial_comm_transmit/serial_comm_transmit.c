/* custom UART based sync comm, serial clock with data transfer at low to high transition, with 8 bit data, no parity, LSB bit transfer first */

#include <reg52.h>
sbit SW_PIN                = P0^0; 
sbit ERROR_LED_PIN         = P1^4;
sbit SERIAL_SEND_CLK_PIN   = P1^5;
sbit SW_LED_PIN            = P1^6; 
sbit SERIAL_SEND_DATA_PIN  = P1^7;
	  		           
#define SW_LED_ON_DATA      'Y'
#define SW_LED_OFF_DATA     'N' 
#define NUM_DATA_BITS        8

#define WAIT_MS             (2)
#define CLK_MS              (3)

void Delay_MilliSec(const unsigned int num_milli_sec);
void Serial_Transmit_Byte(const volatile unsigned char *transmit_byte_ptr);

void main()
{
	  unsigned char transmit_byte;
	  
	  SERIAL_SEND_CLK_PIN = 0;
	  SERIAL_SEND_CLK_PIN = 0;
	  SERIAL_SEND_DATA_PIN = 0;
	  SERIAL_SEND_DATA_PIN = 0;
	  ERROR_LED_PIN = 0;
	  ERROR_LED_PIN = 0;
	  SW_LED_PIN = 0;
	  SW_LED_PIN = 0;	  
	  while(1)
	  {
			 while(SW_PIN == 0);
			 while(SW_PIN == 1);
			 SW_LED_PIN =  !SW_LED_PIN;
		     if(SW_LED_PIN == 1)
			    transmit_byte =  SW_LED_ON_DATA;
		     else 
			    transmit_byte =  SW_LED_OFF_DATA;			 
		     Serial_Transmit_Byte(&transmit_byte);       
	  }
}

void Serial_Transmit_Byte(const volatile unsigned char *transmit_byte_ptr)
{
	  unsigned char i;
	 
	  for (i = 0; i < NUM_DATA_BITS; ++i)
	  {
			 SERIAL_SEND_DATA_PIN = (transmit_byte_ptr >> i) & 0x01;
	      Delay_MilliSec(WAIT_MS);
			 SERIAL_SEND_CLK_PIN = 1;
			 Delay_MilliSec(CLK_MS);
			 SERIAL_SEND_CLK_PIN = 0;
			 Delay_MilliSec(CLK_MS);  	   	 
	  }
	  return;	
}

void Delay_MilliSec(const unsigned int num_milli_sec)
{
	  unsigned int i;
	  unsigned char j;
	
	  for (i = 0; i < num_milli_sec; i++)
	  	for (j = 0; j < 112; j++);	
}

