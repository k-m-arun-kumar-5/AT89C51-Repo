#include <stdio.h>
#define NUM_DATAS   (4)

void Calc_Checksum(const unsigned char *const data_ptr, unsigned char *const checksum_byte_ptr, const unsigned char num_datas);
unsigned char Test_Checksum(const unsigned char *const data_ptr, const unsigned char *const checksum_byte_ptr, const unsigned char num_datas);

int main()
{
    unsigned char data[NUM_DATAS + 1] = {0x25, 0x62, 0x3f, 0x52}, checksum_byte;
    
    Calc_Checksum(data, &checksum_byte, NUM_DATAS);
    if(Test_Checksum(data, &checksum_byte, NUM_DATAS))
    {
         printf("\n Data(s) corrupt");                  
    }
    else
    {
         printf("\n Data(s) safe");
    }
    getch();
    return 0;
}

void Calc_Checksum(const unsigned char *const data_ptr, unsigned char *const checksum_byte_ptr, const unsigned char num_datas)
{
    unsigned char i;
    
    *checksum_byte_ptr = 0;
    for(i = 0; i < num_datas; ++i)
    {
         *checksum_byte_ptr += *(data_ptr + i);    
    }
    *checksum_byte_ptr = ~(*checksum_byte_ptr) + 1;
    return; 
}

unsigned char Test_Checksum(const unsigned char *const data_ptr, const unsigned char *const checksum_byte_ptr, const unsigned char num_datas)
{
     unsigned char i, sum = 0;
    
    for(i = 0; i < num_datas; ++i)
    {
         sum += *(data_ptr + i);    
    }
    sum += *checksum_byte_ptr;
    
    if(sum != 0)
        return 1;
    return 0;       
}
