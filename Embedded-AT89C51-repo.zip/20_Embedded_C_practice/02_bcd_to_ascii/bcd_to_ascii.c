/* A PROGRAM to convert packed BCD to 2 ASCII numbers, in little endian format  */

#include <stdio.h>

#define CONV_PACK_BCD  0x29

void Pack_BCD_to_ASCII_Conv(unsigned char *const result_ascii_ptr, unsigned char packed_bcd);
void ASCII_to_Pack_BCD_Conv(const unsigned char *const result_ascii_ptr, unsigned char *packed_bcd_ptr);

int main()
{
	unsigned char result_ascii[2], packed_bcd = CONV_PACK_BCD, result_packed_bcd; 
	
	Pack_BCD_to_ASCII_Conv(result_ascii, packed_bcd);
	ASCII_to_Pack_BCD_Conv(result_ascii, &result_packed_bcd);
	printf("\n Ascii[0]: 0x%x, Ascii[1]: 0x%x, result BCD : 0x%x", result_ascii[0], result_ascii[1], result_packed_bcd);
	getch();
	return 0;
}

void Pack_BCD_to_ASCII_Conv(unsigned char *const result_ascii_ptr, unsigned char packed_bcd)
{
	result_ascii_ptr[0] = (packed_bcd & 0x0F) | 0x30;
	result_ascii_ptr[1] = ((packed_bcd & 0xF0) >> 4) | 0x30; 
	
	return;
}

void ASCII_to_Pack_BCD_Conv(const unsigned char *const ascii_ptr, unsigned char *packed_bcd_ptr)
{
     *packed_bcd_ptr = (ascii_ptr[0] & 0x0f) | ((ascii_ptr[1] & 0x0f) << 4);
     
     return;
}
