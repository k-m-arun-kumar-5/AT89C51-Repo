
#include <reg52.h>

sbit LED_PIN   = P1^2;
void Delay_Timer();

void main()
{
	  unsigned char i, j ;
	
	  LED_PIN = 0;
	  LED_PIN = 0;
	  TMOD = 0x02;
	  TH0 = 6;
	  while(1)
		{
			 for(i = 0 ; i < 255U; ++i)
			    for(j = 0 ; j < 20U; ++j)
			      Delay_Timer();
			  LED_PIN = ~LED_PIN;
		}
}

/* delay approximate = 250 * 12/11.0592 MHz */
void Delay_Timer()
{
	  TR0 = 1;
	  while(TF0 == 0);
	  TR0 = 0;
	  TF0 = 0;
    return;	
}