
#include <reg52.h>
#define RCV_MAX_CHARS  10
sbit COMM_OVER_LED   = P1^2;
sbit SEND_SW  = P2^5;

void UART_Tx_Str(unsigned char * const tx_ptr);
void UART_Rcvd_Char(unsigned char *const rcvd_arr);
void UART_Tx_Char(unsigned char tx_char);
void main()
{
	  unsigned char tx_arr[] = ">", rcv_char;
	
	  COMM_OVER_LED = 0;
  	COMM_OVER_LED = 0;
	  TMOD = 0x20;
	  TH1 = -3; 
	  SCON = 0X50;
	  TR1 = 1;
	  while(1)
		{			
        while(SEND_SW	== 0);
        while(SEND_SW	== 1);
			  UART_Tx_Str(tx_arr);
		  	while(1)
				{
			     UART_Rcvd_Char(&rcv_char);
			     if(rcv_char != '\r')
			        UART_Tx_Char(rcv_char);
				   else
				   {
					    COMM_OVER_LED = 1; 
				      while(1);
				   }
			  }
		}
}

void UART_Tx_Str(unsigned char *const tx_ptr)
{
	 unsigned char i = 0;
	
	 while(*(tx_ptr + i))
	 {
		 UART_Tx_Char(*(tx_ptr + i));
		 ++i;
	 }
}

void UART_Tx_Char(unsigned char tx_char)
{
   SBUF = tx_char;
	 while(TI == 0);
	 TI = 0;		
}

void UART_Rcvd_Char(unsigned char *const rcvd_char_ptr)
{
	 while(RI == 0);
	 *(rcvd_char_ptr) = SBUF;
	 RI = 0;
	 return;	 
}
	