/* ********************************************************************
FILE                 : Elap_232.c

PURPOSE              : 	Simple library function for keeping track of elapsed time.
                        Demo version to display time on PC screen via RS232 link.										 
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : 

CHANGE LOGS          :

*****************************************************************************/	
#include "main.h"
#include "Elap_232.h"
#include "PC_O.h"

// ------------------- Public variable definitions -----------------
/* elapsed time in hour, minute and second */
tByte Hou_G;
tByte Min_G;
tByte Sec_G;

// -------------------Public variable declarations --------------------

// See Char_Map.c
extern const char code CHAR_MAP_G[10]; 

// ------------------ private constants -------------------------
/* The transmit buffer length (MAX IS 127; MIN is 1) */
#define PC_LINK_TRAN_BUFFER_LENGTH   (30U)

/*------------------------------------------------------------*-
FUNCTION NAME  :  Elapsed_Time_RS232_Init

DESCRIPTION    :  Init function for simple library displaying elapsed
                  time on PC via RS-232 link.
	
INPUT          :  

OUTPUT         : 

NOTE           :  Precise tick intervals are only possible with certain 
  oscillator / tick interval combinations. For eg If timing is important,
  you should check the timing calculations manually by using simulator. 
	If you require both accurate baud rates and accurate EOS timing, use an
  11.0592 MHz crystal and a tick rate of 5, 10, 15, � 60 or 65 ms. 
	Such �divide by 5� tick rates are precise with an 11.0592 MHz crystal.
-*------------------------------------------------------------*/
void Elapsed_Time_RS232_Init(void)
   {
   Hou_G = 0;
   Min_G = 0;
   Sec_G = 0;
   }
/*------------------------------------------------------------*-
FUNCTION NAME  :  Elapsed_Time_RS232_Update

DESCRIPTION    :  Function for displaying elapsed time on PC Screen.
	
INPUT          :  

OUTPUT         : 

NOTE           :  *** Must be called once per second ***
	 Precise tick intervals are only possible with certain 
  oscillator / tick interval combinations. For eg If timing is important,
  you should check the timing calculations manually by using simulator. 
	If you require both accurate baud rates and accurate EOS timing, use an
  11.0592 MHz crystal and a tick rate of 5, 10, 15, � 60 or 65 ms. 
	Such �divide by 5� tick rates are precise with an 11.0592 MHz crystal.
-*------------------------------------------------------------*/
void Elapsed_Time_RS232_Update(void)     
   {
   char Time_Str[PC_LINK_TRAN_BUFFER_LENGTH] = "\rElapsed time:               ";
   /* */
   if (++Sec_G == 60)  
      { 
      Sec_G = 0;
      
      if (++Min_G == 60)  
         {
         Min_G = 0;
           
         if (++Hou_G == 24)  
            { 
            Hou_G = 0;
            }
         }
      }

   Time_Str[15] = CHAR_MAP_G[Hou_G / 10];
   Time_Str[16] = CHAR_MAP_G[Hou_G % 10];

   Time_Str[18] = CHAR_MAP_G[Min_G / 10];
   Time_Str[19] = CHAR_MAP_G[Min_G % 10];

   Time_Str[21] = CHAR_MAP_G[Sec_G / 10];
   Time_Str[22] = CHAR_MAP_G[Sec_G % 10];
  
   // We don't display seconds in this version.
   // We simply use the seconds data to turn on and off the colon
   // (between hours and minutes) 
   if ((Sec_G % 2) == 0)
      {
      Time_Str[17] = ':';
      Time_Str[20] = ':';
      }
   else
      {
      Time_Str[17] = ' ';
      Time_Str[20] = ' ';
      }

   PC_LINK_O_Write_String_To_Buffer(Time_Str);
   }

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
