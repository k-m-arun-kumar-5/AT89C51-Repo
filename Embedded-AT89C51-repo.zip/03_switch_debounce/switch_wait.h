/**************************************************************************
   FILE          :    switch_wait.h
 
   PURPOSE       :    Type declarations for the switch_wait.c
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
 KNOWN BUGS      :
 
  NOTE           :   switch_wait.c for details.
	
  CHANGE LOGS     :  TEST is used to fine tune software timeout  of 10 sec is added
                     TIMEOUT code segment is added
	   
 **************************************************************************/
#ifndef _SWITCH_WAIT_H
#define _SWITCH_WAIT_H

/* public constants, variables and function prototypes are recoginized and accessed by 
 any functions defined in .c file and  this file must be included in .c file.
 for public variables, functions must not define same public variable name, else only auto 
 or  static variable defination in that function will  access for that same varible name */
// ------ Public constants ------------------------------------

// Return values from Switch_Get_Input()
#define SWITCH_NOT_PRESSED (bit) 0
#define SWITCH_PRESSED (bit) 1

/* Added for TIMEOUT : begin */
/* TEST to to finetune the software timeout loops to match particular hardware. */
// #define TEST     1

/* Vary this value to change the loop duration
 THESE ARE APPROX VALUES FOR VARIOUS TIMEOUT DELAYS ON 8051, 12 MHz, 12 Osc / cycle
  MUST BE FINE TUNED FOR YOUR APPLICATION 
 Timings vary with compiler optimisation settings */
// in tWord size 
#define LOOP_TIMEOUT_INIT_001ms 65435U
#define LOOP_TIMEOUT_INIT_010ms 64535U
#define LOOP_TIMEOUT_INIT_500ms 14535U
// in tLong size 
#define LOOP_TIMEOUT_INIT_10000ms 4293244336UL  
#ifdef TEST 
void Test_Timeout();	
#endif
/* added end: TIMEOUT */
// ------ Public function prototype ---------------------------
void SWITCH_Init(void);
bit SWITCH_Get_Input(const tByte);
#endif
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
