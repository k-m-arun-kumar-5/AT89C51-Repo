/* ********************************************************************
FILE                  : display_count.c

PURPOSE               : initialize and display an unsigned char on a port to display 
    number of times, a valid switch pressed is on and released. 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :

NOTE                  : 

CHANGE LOGS           :

*****************************************************************************/ 

#include "main.h"
#include "port.h"
#include "display_count.h"
/*------------------------------------------------------------*-
FUNCTION NAME  : DISPLAY_COUNT_Init

DESCRIPTION     : Initialisation function for the COUNT_PORT

INPUT          : none

OUTPUT         : initialize COUNT_PORT of output to 0.

NOTE           : 
-*------------------------------------------------------------*/
void DISPLAY_COUNT_Init(void)
{
COUNT_PORT = 0x00;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : DISPLAY_COUNT_Update()

DESCRIPTION     : Simple function to display tByte data (COUNT)
on LEDs connected to port (COUNT_PORT).

INPUT          : total number of times valid switch is pressed on and released.

OUTPUT         : update port COUNT_PORT by input parameter 

NOTE           : 
-*------------------------------------------------------------*/
void DISPLAY_COUNT_Update(const tByte COUNT)
{
COUNT_PORT = COUNT;
}
/*------------------------------------------------------------*-
---- END OF FILE -------------------------------------------- */
