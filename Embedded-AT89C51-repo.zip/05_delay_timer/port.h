/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :  K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H
/* reg52h is the one of the system header file of your own program. For <> enclosed, preprocessor will look 
   for the reg52.h in the predefined directory path */
#include <reg52.h>

#define PIN_LED 5
#define LED_PORT  P2
sbit LED_pin = LED_PORT^PIN_LED;

// Used for manually checking timing (in simulator) by using preload value for Timer 0.  
#define RELOADH_PORT  P1
#define RELOADL_PORT  P0
#endif
