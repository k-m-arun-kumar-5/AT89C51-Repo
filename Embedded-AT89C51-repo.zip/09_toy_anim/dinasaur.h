/* ********************************************************************
FILE                 : dinasaur.h

PURPOSE              :  type declaration for dinasaur.c
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : see dinasaur.c for details 

CHANGE LOGS          :

*****************************************************************************/	
#ifndef _DINOSAUR_H
#define _DINOSAUR_H

// ------ Public function prototypes -------------------------------

void DINOSAUR_Init(void);
void DINOSAUR_Update(void);

// -------- public data constant definition -----------------

/* system ticks interval in m sec. for Every TICK_INTERVAL, application Task followed by e0S(system Task)
   is executed. NOTE: make sure that SYSTEM_TICK_INTERVAL is large enough that uC executing maximum time 
	 required to start and completes executing Application task and system task(sEOS_Go_To_Sleep) 	*/
	 
#define SYSTEM_TICK_INTERVAL  (50U)

/* good performance and optimization are required */
#define   OPTIMIZE     1

#endif

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
