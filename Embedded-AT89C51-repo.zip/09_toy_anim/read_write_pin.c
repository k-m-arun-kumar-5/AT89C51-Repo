/* ********************************************************************
FILE                  : read_write_pin.c

PURPOSE               : write a given bit to PIN in  port.
                        Read a status of PIN in port.
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :

NOTE                  : only when OPTIMIZE is not defined, this file will be used.

CHANGE LOGS           :

*****************************************************************************/ 
#ifndef OPTIMIZE
#include "main.h"
#include "port.h"
#include "read_write_pin.h"

/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to CTRL_PORT port's PIN, without affecting
                  other pin status of CTRL_PORT.
                . 0 is the least pin value and 7 is the most pin value. 

INPUT          :  CTRL_PORT port's PIN and its value to be written. 

OUTPUT         : none

NOTE           : NOTE - YOU CANNOT USE PORT ADDRESS AS ONE OF 
	                THE PARAMETER OF A FUNCTION
-*------------------------------------------------------------*/
/* when this function actual arguments is used and replacing CTRL_PORT by port. All reference to this function 
   are matched by data tytes and nos of arguments, then program gets stuck at Dinasour_Init() and 
	 does not execute the FSM sequence. No error during compilaton. make use that OPTIMIZE is not defined and
	 When Write_Bit( const tByte PIN, const bit VALUE) is used, then it works fine as desired, but not optimized
	 and not an efficient performance.  */
/* void Write_Bit( tByte port, const tByte PIN, const bit VALUE) */


 void Write_Bit( const tByte PIN, const bit VALUE)
{
unsigned char p = 0x01; // 00000001
/* Left shift appropriate number of places, 
	 so for PIN = 2, then p = 00000100 */
p <<= PIN;
// If we want 1 to be written at this PIN
if (VALUE == 1)
{
	/* set 1 to PIN and all other pins of port are unchanged */
CTRL_PORT |= p; 
return;
}
/* If we want 0 output at this pin, then only that PIN of port is set to 0
  and all other pins of port  are unchanged. */
p = ~p; // Complement
/* if PIN = 2, then p = 11111011 */
CTRL_PORT &= p; // Bitwise AND
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Read_Bit

DESCRIPTION     : return status of PIN of port, CTRL_PORT.
                 First write 1 to that PIN of port ,before reading PIN status in port. 
                 only PIN status is returned and other pins in port are discarded.
                 0 is the least pin value and 7 is the most pin value. 

INPUT          : CTRL_PORT port's PIN.

OUTPUT         : status of PIN in port CTRL_PORT. 

NOTE           : 
-*------------------------------------------------------------*/
bit Read_Bit(const tByte PIN)
{
	bit  status;
unsigned char p = 0x01; // 00000001
/* Left shift appropriate number of places, 
	so for PIN = 5, then  p = 00100000 */ 
p <<= PIN;
/* Write a 1 to the PIN in port (to set up for reading),
  without affecting status of other pins in port.	*/
Write_Bit( PIN, 1);
/* Read the PIN in  port (bitwise AND) and return. only
	 PIN status is returned and status of other pins in port are discarded */

 return (CTRL_PORT & p); 
}
#endif
/*------------------------------------------------------------*-
------------------------- END OF FILE ---------------------
-----------------------------------------------------*/
