/**************************************************************************
   FILE          :    read_write_pin.h
 
   PURPOSE       :    Type declarations for the read_write_pin.c
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    read_write_pin.c for details.
	
  CHANGE LOGS     :
	   
 **************************************************************************/

#ifndef _READ_WRITE_H
#define _READ_WRITE_H

#include "main.h"
// ------ Public function prototypes --------------------------
void Write_Bit( const tByte PIN, const bit VALUE);
bit Read_Bit( const tByte PIN);
#endif
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
