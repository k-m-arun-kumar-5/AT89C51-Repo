/* ********************************************************************
FILE                 : dinasaur.c

PURPOSE              : Demo of multi-state (time driven) architecture: animatronic Dinosaur control system.
                       Initial state of traffic system is set and implements FSM of
											 an animatronic dinosaur and FSM is processed every UPDATE_PERIOD.
											 For simplicity and demo, corresponding pin flashs on corresdinding to the current state of system,
											 ie, when current state of system = sleep, sleep_pin is flashs on and other CTRL_port
											 pins of system is switched off, making sure that unused pins by system on CTRL_port are unaffected.  
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : FSM of animatronic Dinosaur control system is only time driven, 
                      so inputs from outside or inside does not affect behaviour of system, 
											so it highly predicatible. 
                      Animatronic movements of dinosaur control system are not implemented. 											

CHANGE LOGS          :

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "dinasaur.h"

#ifndef OPTIMIZE
   #include "read_write_pin.h"
#endif
// ------ Private data type declarations ---------------------------
// Possible animatronic Dinosaur control system states
typedef enum {SLEEPING, WAKING, GROWLING, ATTACKING} eDinosaur_State;

// ------ Private function prototypes ------------------------------
void DINOSAUR_Perform_Sleep_Movements(void);
void DINOSAUR_Perform_Waking_Movements(void);
void DINOSAUR_Growl(void);
void DINOSAUR_Perform_Attack_Movements(void);

// ------ Private constants ----------------------------------------
// Times in each of the (four) possible states
// (Times are in seconds)
#define SLEEPING_DURATION    (255U)
#define WAKING_DURATION      (60U)
#define GROWLING_DURATION    (40U) 
#define ATTACKING_DURATION   (120U)

/* logic for on and off of animatronic Dinosaur system's ctrl _port's pin.
  depending of HW interfacing ctrl _port, logic can changed. */
#define ON         (1U)
#define OFF        (0U)


// ------ Private variables ----------------------------------------
// The current state of the system
static eDinosaur_State Dinosaur_state_G;

/* instanteous total time stayed in a particular state, in steps of UPDATE_PERIOD. 
 Must reset when change of state occurs and starts counting in new state and process repeats */
static tLong Time_in_state_G;

/*------------------------------------------------------------*-
FUNCTION NAME  : DINOSAUR_Init

DESCRIPTION    : Prepare for the dinosaur activity.
                 initial state of system =  SLEEPING and
								 for demo only the Sleep pin of system is on and all other pins of system
                 is off, making sure that other unused pins of ctrl port are unaffected.								 

INPUT          : 

OUTPUT         : LED of sleep pin flashes on. wake pin, growl pin and attack pin of system port are switched off. 

NOTE           : 
-*------------------------------------------------------------*/

void DINOSAUR_Init(void)
   {
   // Initial animatronic Dinosaur control system state = sleeping
   Dinosaur_state_G = SLEEPING; 	 
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : DINOSAUR_Update

DESCRIPTION    :  Implements FSM of animatronic Dinosaur control system, initiates and 
	                produces animatronic movement of Dinosaur. 
              	 1: when uC resets, animatronic Dinosaur is SLEEPING state.
	               2: In SLEEPING state, animatronic system produces movements, which imitates 
	                 as SLEEPING, and stays in SLEEPING state for duration of SLEEPING_DURATION,
                	 then changes it state to WAKING. 	 
	               3: In WAKING state, animatronic system produces movements, which imitates as Waking,
                	 stays in WAKING state for duration of WAKING_DURATION, then changes it
                	 state to GROWLING.
	               4:	In GROWLING state, animatronic system produces movements, which imitates as growling,
                	 stays in GROWLING state for duration of GROWLING_DURATION, then changes it
                	 state to ATTACKING.
	               5: In ATTACKING state, animatronic system produces movements, which imitates as attacking,
                	 stays in ATTACKING state for duration of ATTACKING_DURATION, then changes it
                	 state to SLEEPING.
	                6: go to step 2 and repeats.
	 
INPUT          :  current state and instanteous of total time duration stayed in a particular state of system.

OUTPUT         : control 

NOTE           : Must be called once every UPDATE_PERIOD.
	              System states will usually be represented by means of a
	              switch statement in the operating system ISR.  
-*------------------------------------------------------------*/

void DINOSAUR_Update(void)
   {
   switch (Dinosaur_state_G)
      {
		 /* current system state = sleeping */		
      case SLEEPING: 
         {
		 // Call relevant function to produce movements that imitates as sleeping
		 DINOSAUR_Perform_Sleep_Movements();
					 
        /* if instanteous total time stayed in SLEEPING reachs predeterminted max of sleep duration,
           resets Time_in_state var and change the system state to WAKING so next time 
					 DINOSAUR_Update() is called,  Time_in_state var increments by 1 and state is WAKING, and
          process repeats */
         if (++Time_in_state_G == SLEEPING_DURATION)
            {
            Dinosaur_state_G = WAKING;
            Time_in_state_G = 0;
            }

         break;
         }
     /* current system state = WAKING */	
      case WAKING: 
         {
		 // Call relevant function to produce movements that imitates as waking
		 DINOSAUR_Perform_Waking_Movements();
       /* if instanteous total time stayed in WAKING reachs predeterminted max of waking duration,
           resets Time_in_state var and change the system state to GROWLING so next time 
					 DINOSAUR_Update() is called,  Time_in_state var increments by 1 and state is GROWLING, and
          process repeats */
					 
         if (++Time_in_state_G == WAKING_DURATION)
            {
            Dinosaur_state_G = GROWLING;
            Time_in_state_G = 0;
            }

         break;
         }
      /* current system state = GROWLING */	
      case GROWLING: 
         {
		 // Call relevant function to produce movements that imitates as growling
		 DINOSAUR_Growl();
        /* if instanteous total time stayed in GROWLING reachs predeterminted max of growling duration,
           resets Time_in_state var and change the system state to ATTACKING so next time 
					 DINOSAUR_Update() is called,  Time_in_state var increments by 1 and state is ATTACKNG, and
          process repeats */
         if (++Time_in_state_G == GROWLING_DURATION)
            {
            Dinosaur_state_G = ATTACKING;
            Time_in_state_G = 0;
            }

         break;
         }
      /* current system state = ATTACKING */	
      case ATTACKING: 
         {
		// Call relevant function to produce movements that imitates as attacking
		 DINOSAUR_Perform_Attack_Movements();
      /* if instanteous total time stayed in ATTACKING reachs predeterminted max of attacking duration,
           resets Time_in_state var and change the system state to SLEEPING so next time 
					 DINOSAUR_Update() is called,  Time_in_state var increments by 1 and state is SLEEPING, and
          process repeats */
         if (++Time_in_state_G == ATTACKING_DURATION)
            {
            Dinosaur_state_G = SLEEPING;
            Time_in_state_G = 0;
            }

         break;
         }
      }
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : DINOSAUR_Perform_Sleep_Movements

DESCRIPTION    : Produces movements that imitates as sleeping. In sleeping state, the animatronic dinosaur 
	               will be largely motionless, but will be obviously \91breathing\92.
                 Irregular snoring noises, or slight movements during this time, will be added advantage.
                 For demo, sleep pin of system flashes on and other pins of system port is switched off, 
	               making sure that unused pins by system on CTRL_PORT are not affected.	               
INPUT          : 

OUTPUT         : LED of sleep pin flashes on. wake pin, growl pin and attack pin of system port are switched off. 

NOTE           : feed the control signals so that it produces movements that imitates as sleeping.
	               
-*------------------------------------------------------------*/
void DINOSAUR_Perform_Sleep_Movements(void)
   {
		 /* for Demo only, only sleep pin flashs on and other pins(wake, growl and attack) of 
		 system port is switched off. Unused pins by system on CTRL_PORT are not affected.   */
		 #ifdef OPTIMIZE
		 sleep_pin = ON;
     wake_pin = OFF;
     growl_pin = OFF;
    attack_pin = OFF; 
		 #else			 
		 /* Same result as done by sleep_pin = ON , wake_pin = OFF, growl_pin = OFF, attack_pin = OFF is performed 
		   by the Write_Bit()	sequences . When Write_Bit() is used warning of multiple call to segment Write_Bit, which is 
		   not an issue in our case and not an optimized way as this functon is called many times and execution time 
  		 more compared to just using code as sleep_pin and sequence. */	 
		 
   Write_Bit( SLEEP_PIN, ON);
	 Write_Bit( WAKE_PIN, OFF);
	 Write_Bit( GROWL_PIN, OFF); 
	 Write_Bit( ATTACK_PIN, OFF); 
   #endif		 
   /* Animatronic movements for sleeping of dinosaur control system should be performed here. */		 
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : DINOSAUR_Perform_Waking_Movements

DESCRIPTION    : Produces movements that imitates as waking. In waking state, the animatronic dinosaur 
	               will begin to wake up. Eyelids will begin to flicker. Breathing will become more rapid.
                 For demo, wake pin of system flashes on and other pins of system port is switched off,
              	 making sure that unused pins by system on CTRL_PORT are not affected.	 
	 
INPUT          : 

OUTPUT         : LED of wake pin flashes on. Sleep pin, growl pin and attack pin of system port are switched off. 

NOTE           : feed the control signals so that it produces movements that imitates as waking.
	               
-*------------------------------------------------------------*/

void DINOSAUR_Perform_Waking_Movements(void)
   {
	 #ifdef OPTIMIZE
		 sleep_pin = OFF;
     wake_pin = ON;
     growl_pin = OFF;
    attack_pin = OFF; 
		 #else	 
   /* for Demo only, only wake pin flashs on and other pins(sleep, growl and attack) of 
		 system port is switched off. Unused pins by system on CTRL_PORT are not affected.   */
   Write_Bit( SLEEP_PIN, OFF);
	 Write_Bit( WAKE_PIN, ON);
	 Write_Bit( GROWL_PIN, OFF); 
	 Write_Bit( ATTACK_PIN, OFF); 
	#endif	 
   /*  Animatronic movements for waking of dinosaur control system should be performed here. */
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : DINOSAUR_Growl

DESCRIPTION    : Produces movements that imitates as growling. In growling state, the animatronic 
	              dinosaur eyes will suddenly open, and the dinosaur will emit a very loud growl. 
	              Some further movement and growling will follow. For demo, growl pin of system flashes 
	              on and other pins of system port is switched off, making sure that unused pins by system 
	               on CTRL_PORT are not affected.	               

INPUT          : 

OUTPUT         : LED of growl pin flashes on. Sleep pin, wake pin and attack pin of system port are switched off. 

NOTE           : feed the control signals so that it produces movements that imitates as growling.
	               
-*------------------------------------------------------------*/
void DINOSAUR_Growl(void)
   {
	#ifdef OPTIMIZE
		 sleep_pin = OFF;
     wake_pin = OFF;
     growl_pin = ON;
    attack_pin = OFF; 
		 #else	 
   /* for Demo only, only growl pin flashs on and other pins(sleep, wake and attack) of 
		 system port is switched off. Unused pins by system on CTRL_PORT are not affected.   */
   Write_Bit( SLEEP_PIN, OFF);
	 Write_Bit( WAKE_PIN, OFF);
	 Write_Bit( GROWL_PIN, ON); 
	 Write_Bit( ATTACK_PIN, OFF); 
	#endif	 
   /*  Animatronic movements for growling of dinosaur control system should be performed here. */
   }
/*------------------------------------------------------------*-
FUNCTION NAME  : DINOSAUR_Perform_Attack_Movements

DESCRIPTION    : Produces movements that imitates as attacking. In attacking state, the animatronic
              	 dinosaur must have rapid \91random\92 movements towards the audience. Lots of louder noise
                 that should be heard few hundred metres away. For demo, attack pin of system flashes 
	               on and other pins of system port is switched off, making sure that unused pins by system 
	               on CTRL_PORT are not affected.     	 

INPUT          : 

OUTPUT         : LED of attack pin flashes on. Sleep pin, wake pin and growl pin of system port are switched off. 

NOTE           : feed the control signals so that it produces movements that imitates as attacking.
	               
-*------------------------------------------------------------*/
void DINOSAUR_Perform_Attack_Movements(void)
   {
	#ifdef OPTIMIZE
		 sleep_pin = OFF;
     wake_pin = OFF;
     growl_pin = OFF;
    attack_pin = ON; 
	#else	 
		 
  /* for Demo only, only attack pin flashs on and other pins(sleep, wake and growl) of 
		 system port is switched off. Unused pins by system on CTRL_PORT are not affected.  */
   Write_Bit( SLEEP_PIN, OFF);
	 Write_Bit( WAKE_PIN, OFF);
	 Write_Bit( GROWL_PIN, OFF); 
	 Write_Bit( ATTACK_PIN, ON);  
	#endif

		 
   /*  Animatronic movements for attacking of dinosaur control system should be performed here. */ 
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
