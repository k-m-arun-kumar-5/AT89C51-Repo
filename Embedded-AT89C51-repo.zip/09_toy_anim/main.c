/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : program for the 8051/8052 with demo of control of an animatronic dinosaur
                          (Application Task) using a simple sEOS.
                      									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : implements sEOS, a simple time triggered ,nonpremptive and single application task executing embedded OS.
                       Assume that control of an animatronic dinosaur follows time-driven, Multi-State architecture and so it
											will perform well by executing a sequence of states in a pre-determined manner, and it is highly predictable.	
                       Animatronic movements of dinosaur control system are not implemented.											
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "simple_EOS.h"
#include "dinasaur.h"

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :1: Initialize state of animatronic dinosaur is sleeping. 
                2: configure Timer T2 for automatic reload with preload and recapture values,
								 corresponding to SYSTEM_TICK_INTERVAL msec and run the T2.								
								3: put the CPU of 8051/8052 in idle mode and Every  SYSTEM_TICK_INTERVAL when T2 overflow interrupt occurs, 
                4: for every UPDATE_PERIOD, and finite-state machine (FSM) of animatronic dinosaur system are processed. 							
                5: go to step 3, and repeat
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main(void)
   {
		 /* ========= begin : USER CODE INITIALIZE ========== */
		  // configure to control animatronic dinosaur control system.
       DINOSAUR_Init(); 
		
	/* ========= end : USER CODE INITIALIZE ========== */	 
    /* Set up simple EOS. configure Timer 2 and start running Timer 2, 
		 with SYSTEM_TICK_INTERVAL time in ms ticks  */ 
   sEOS_Init_Timer2(SYSTEM_TICK_INTERVAL);   
   
   while(1) // Super Loop
      {
				/* uC enters idle mode to save power consumed by CPU. But timers, UART and other
				peripherals continue to work after idle mode */
			/* ============ PERIODIC SYSTEM TASK EXECUTION ============= */	
      sEOS_Go_To_Sleep();  
			/* here uC does not execute. When interrupt occurs, uC executes its corresponding ISR.
         in our case, only Timer 2 overflow interrupt will occur, which executes its ISR, sEOS_ISR()	*/	
			/* ISR of Timer 2 executes application task */	
      }
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/	 
