/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : program for the 8051/8052 with single traffic-light sequencing
                        (Indian style)(Application Task) using a simple sEOS.
                      									 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : implements sEOS, a simple time triggered ,nonpremptive and single application task executing embedded OS.
                        Single traffic-light sequencing follows time-driven, Multi-State architecture and 
												will perform well by executing a sequence of states in a pre-determined manner, so it is highly predictable.
												Traffic lights are connected to Traffc port of uC.
												
                       
                       
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "simple_EOS.h"
#include "T_Lights.h"


/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :1: Initialize state of traffic system is RED. 
                2: configure Timer T2 for automatic reload with preload and recapture values,
								 corresponding to SYSTEM_TICK_INTERVAL msec and run the T2.								
								3: put the CPU of 8051/8052 in idle mode and Every  SYSTEM_TICK_INTERVAL when T2 overflow interrupt occurs, 
                4: for every UPDATE_PERIOD, traffic lghts are updated and displayed, and finite-state machine (FSM) 
							  	of  traffic system are processed. 							
                5: go to step 3, and repeat
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main(void)
   {
		 /* ========= begin : USER CODE INITIALIZE ========== */
		 // Prepare to run traffic sequence. Initialize state of traffic signal states is RED.
   TRAFFIC_LIGHTS_Init(RED);  
		
	/* ========= end : USER CODE INITIALIZE ========== */	 
    /* Set up simple EOS. configure Timer 2 and start running Timer 2, 
		 with SYSTEM_TICK_INTERVAL time in ms ticks  */ 
   sEOS_Init_Timer2(SYSTEM_TICK_INTERVAL);   
   /* */
   while(1) // Super Loop
      {
				/* uC enters idle mode to save power consumed by CPU. But timers, UART and other
				peripherals continue to work after idle mode */
			/* ============ PERIODIC SYSTEM TASK EXECUTION ============= */	
      sEOS_Go_To_Sleep();  
			/* here uC does not execute. When interrupt occurs, uC executes its corresponding ISR.
         in our case, only Timer 2 overflow interrupt will occur, which executes its ISR, sEOS_ISR()	*/	
			/* ISR of Timer 2 executes application task */	
      }
   }

/*------------------------------------------------------------------*-
  ---- END OF FILE -------------------------------------------------
-*------------------------------------------------------------------*/
