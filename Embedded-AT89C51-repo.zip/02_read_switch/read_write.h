/**************************************************************************
   FILE          :    read_write.h
 
   PURPOSE       :    Type declarations for the read_write.c
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :    read_write.c for details.
	
  CHANGE LOGS     :
	   
 **************************************************************************/

#ifndef _READ_WRITE_H
#define _READ_WRITE_H

#include "main.h"
// ------ Public function prototypes --------------------------
tByte	Read_Switch(void);
void	Write_Port(const tByte DATA);

#endif
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
