/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :   program for the 8051 for which 2 LED's : LED, LED1 are
                           indefinetely is glows on and off, alternately. ie 
													 if LED glows on, then LED1 is off. After appropiate delay, LED is off 
                           then LED1 glows on. After appropiate delay	process repeats. display
  												 total number of times that LED glows ON to port P0.					 

AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 

CHANGE LOGS            :

*****************************************************************************/
#include <reg52.h>

/**********private variable declaration ***************/
// LED is to be connected to 5th pin in P1 port
sbit LED_pin = P1^5;
// LED is to be connected to 6th pin in P1 port
sbit LED1_pin = P1^6;
// Stores the LED state
bit LED_state_G;
/* total  number of times that LED_pin glows on */
unsigned char count_led_on;
/****************** private Function prototypes ******************/
void LED_FLASH_Init(void);
void LED_FLASH_Change_State(void);
void DELAY_LOOP_Wait(const unsigned int);
void DISPLAY_LED_on(unsigned char count_led_on);
/*------------------------------------------------------------*-
FUNCTION NANE  : main

DESCRIPTION    : LED, LED1 are indefinetely is glows on and off, alternately. ie 
									if LED glows on then LED1 is off and if LED is  off 
                  then LED1 glows on, at appropiate delay. 			 

INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main()
{
LED_FLASH_Init();
while(1)
{
// Change the LED state (OFF to ON, or vice versa)
LED_FLASH_Change_State();
DISPLAY_LED_on(count_led_on);	
	// Delay for *approx* 5000 ms
DELAY_LOOP_Wait(5000);
} 
}

/*------------------------------------------------------------*-
FUNCTION NANE  : LED_FLASH_Init

DESCRIPTION    : Prepare for LED_Change_State() function			 

INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
void LED_FLASH_Init(void)
{
LED_state_G = 0;
	/* write data 0x40 to P1 port, so that only P1.5 ie (only LED glows on)
  	is set initially  and the pins of P1 are 0xFF  */	
P1 = 	0x20; 
count_led_on = 0x00;
}

/*------------------------------------------------------------*-
FUNCTION NANE  : LED_FLASH_Change_State

DESCRIPTION    : Changes the state of an LED (or pulses a buzzer, etc) on a
specified port pin. Must call at twice the required flash rate: thus, for 1 Hz
flash (on for 0.5 seconds, off for 0.5 seconds),this function must be called twice a second.		 

INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
void LED_FLASH_Change_State(void)
{
// Change the LED from OFF to ON (or vice versa)
if (LED_state_G == 1)
{
LED_state_G = 0; /* state of LED pin is OFF */
LED_pin = 0;  /* Switch off the LED */
LED1_pin = 1;	/* LED1 glows on */
}
else
{
LED_state_G = 1;
LED_pin = 1;    /* LED glows on */
LED1_pin = 0;		/* Switch off the LED1 */
/* increment to indicate that LED_pin glows on */	
count_led_on++;	
}

}

/*------------------------------------------------------------*-
FUNCTION NANE  : DELAY_LOOP_Wait

DESCRIPTION    : 	Delay duration varies with parameter.
Parameter is, *ROUGHLY*, the delay, in milliseconds,
on 12MHz 8051 (12 osc cycles). 

INPUT          : DELAY parameter = 5000 so that DELAY_LOOP_Wait()
  requires execution time of around 0.82 ms

OUTPUT         : 

NOTE           : You need to adjust the timing for your application!.
                 use performance analyzer at run time of this function to get execution time
-*------------------------------------------------------------*/

void DELAY_LOOP_Wait(const unsigned int DELAY)
{
unsigned int x, y;
for (x = 0; x <= DELAY; x++)
{
for (y = 0; y <= 120; y++);
}
}
/*------------------------------------------------------------*-
FUNCTION NANE  : DISPLAY_LED_on

DESCRIPTION    : 	update total  number of times that LED_pin glows on

INPUT          : total number of times that LED_pin glows on.

OUTPUT         : port P0 has the total number of times that LED_pin glows on.

NOTE           : 
-*------------------------------------------------------------*/
void DISPLAY_LED_on(unsigned char count_led_on)
{
	 P0 = count_led_on;
}
	
/*-------------------------------------------------------------
---- END OF FILE -------------------------------------------- */
