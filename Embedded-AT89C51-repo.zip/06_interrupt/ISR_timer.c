/* ********************************************************************
FILE                 : ISR_timer.c

PURPOSE              : ISR routine for Timer 2 overflow interrupt occurs
	 
AUTHOR               : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS           : 

NOTE                 : refer book embedded C by PONT on 7.2 section

CHANGE LOGS          :

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "update.h"
/* divisor factor of T2 interrupt overflow occurs */
#define FACTOR    (1000U)
/*------------------------------------------------------------*-
FUNCTION NANE  : T2_overflow_ISR

DESCRIPTION    : flashes led_pin on every 2 timer T2 overflow interrupt occurs.
                 update COUNT_PORT for exactly every one FACTOR value.									 

INPUT          : none

OUTPUT         : 

NOTE           : ISR for T2 timer overflow interrupt for every 1msec
                interrupt is keyword for keil to indicate that function T2_overflow_ISR()
								is ISR for interrupt number INTERRUPT_Timer_2_Overflow.
								(ie) when T2 overflows, it's  referenced as interrupt number(IE) 5 in 8051/8052,
                which transfers program control to address 0x2B in uC.
                bit 5 of the IE register will be linked to a function using �Timer 2 Overflow'								
-*------------------------------------------------------------*/
void T2_overflow_ISR(void) interrupt INTERRUPT_Timer_2_Overflow
{	
	/* Must manually reset the T2 overflow flag, still Timer 2 reload with recapture 
		  register values and automatically starts	T2 timer running */
	 TF2 = 0; 
	/* update COUNT port if total num of T2 interrupt overflows occurs is exactly divisible by FACTOR,*/
  /* eg if interruptT2_count = 120 and FACTOR = 10, then COUNT_PORT = 12, and
    	if interruptT2_count = 125, then COUNT_PORT = 12. COUNT_PORT will be updated only when 
     interruptT2_count is exactly divisible by FACTOR value	*/ 
	if( !(++interruptT2_count % FACTOR))
	{	
	/* update COUNT_PORT for exactly every one FACTOR value.		*/
		Update_count((tByte)(interruptT2_count/FACTOR));		
	}	
	/* if led is on switch it off */
  if(LED_state)
  {
		 LED_state = 0;
		 led_pin = 0;
  }
	/* led flash from off to on */
  else
  {
	    LED_state = 1;
		  led_pin = 1;
	}  	
}
/*------------------------------------------------------------
---- END OF FILE --------------------------------------------
------------------------------------------------------------*/
