/*********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : Program for the 8051 for flashing LED at regular intervals of a pin 
                        in PORT P0 (generic version) by using hardware timer using timer interrupt overflow.
												update COUNT_PORT for every exactly divided by FACTOR value.  
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : LED at 0th pin is connected on the port, P0.
                        P1 port is connected to parallel output.

CHANGE LOGS            :

*****************************************************************************/	
#include "main.h"
#include "port.h"
#include "update.h"
/* --------------------public variable defination -----------------*/
/* interrupt_count is total number of times timer T2 overflow interrupt occurs.
  it resets for every time COUNT_PORT >= MAX_COUNT, to avoid overflow of COUNT_PORT and counts the interrupts again  */
tLong interruptT2_count;
bit LED_state;

/* system ticks interval in m sec. For every TICK_INTERVAL, ISR of Timer T2 overflow interrupt will be executed */
#define SYSTEM_TICK_INTERVAL  (30U) 
/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    : configure Timer 2 and perodically timer T2 overflow interrupt 
                 occurs and ISR of LED flashs on and off every 2 overflow interrupt
		             and update the total number of times T2 overflow interrupt occurs.

INPUT          : none

OUTPUT         : 

NOTE           :  
-*------------------------------------------------------------*/
void main(void)
{
Timer_2_Init(SYSTEM_TICK_INTERVAL);   // Set up Timer 2
/* led_pin switched off */
led_pin = 0;
LED_state = 0;
interruptT2_count = 0;	
EA = 1;   // Globally enable interrupts of 8051/8052 uC
while(1);  // An empty Super Loop
/* periodically for every SYSTEM_TICK_INTERVAL time, ISR of timer T2 overflow interrupt is 
 executed	*/	
}
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
