/**************************************************************************
   FILE          :    delay.h
 
   PURPOSE       :    Type declarations for the delay.c
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
 KNOWN BUGS      :
 
  NOTE           :   delay.c for details.
	
  CHANGE LOGS     :
	   
 **************************************************************************/
#ifndef _DELAY_H
#define _DELAY_H

/* public constants, variables and function prototypes are recoginized and accessed by 
 any functions defined in .c file and  this file must be included in .c file.
 for public variables, functions must not define same public variable name, else only auto 
 or  static variable defination in that function will  access for that same varible name */
 
/* ********************** public function prototype ****************/ 
extern void Delay_Loop(const tWord DELAY_MS);

#endif
/*------------------------------------------------------------*-
---- END OF FILE --------------------------------------------
-*------------------------------------------------------------*/
