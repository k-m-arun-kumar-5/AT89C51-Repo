/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

#include <reg52.h>

#define PORT P2
#define SWITCH_PIN  5
#define LED_PIN     2 
/* Switch is physically connected to port P2, whose pin is 5. pin 0 is least and pin 7 is the most for a 8bit P2 port */
/* sbit does not allocate memory for switch_pin. bit memory of switch_pin is a part of memory address of P2 port  */
sbit switch_pin = PORT^SWITCH_PIN;
/* LED is physically connected to port P2, whose pin is 2. led is used to indicate the status of switch  */
sbit led_pin  = PORT^LED_PIN;

#endif

/*------------------------------------------------------------*-
------------------------- END OF FILE --------------------------
-*------------------------------------------------------------*/
